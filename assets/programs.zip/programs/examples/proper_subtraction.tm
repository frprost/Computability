# Machine from the chapter “Turing machines” (ex-sous)
q0 1 B q0
q0 B R q1
q1 1 R q1
q1 B R q2
q2 1 R q2
q2 B L q3
q3 1 B q3
q3 B L q4
q4 1 L q5
q5 1 L q5
q5 B L q6
q6 B R q8
q6 1 L q7
q7 1 L q7
q7 B R q0
q8 B R q9
q9 1 B q8
